# universalmope
IF YOU HAVE ANY ISSUE OR COMMERCIAL ISSUE WITH THIS PLEASE CONTACT ME TO THIS EMAIL : ahmetcanfr@hotmail.com
JOIN THIS SERVER FOR HELP: https://discord.gg/KbFB8XhhrW

NOTICE : DO NOT OPEN AN PUBLIC SERVER , I AM NO RESPONSIBLE FOR ANY ISSUES WITH AG WITH YOUR SERVER.

An sandbox of mope.io.

Here multiples examples of how it works

Abilities reload time

File : playergameplay/abilitiesswitch.js
time is expressed in seconds.



```javascript
  case 37://trex bite
            button = {

                abil_currentclick: 0,
                abil_Type: 37,
                abil_usable: true,
                abil_recharging: false,
                abil_possible: true,
                abil_active: false,
                abil_time: 8,//time of ability , you can change it.
                abil_timestamp: Date.now(),
                abil_noflags: [20, 9, 19],
                abil_bardivideusable: 1,
            }
      break
      }
```

